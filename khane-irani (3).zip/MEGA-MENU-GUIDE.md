# راهنمای استفاده از مگامنو

## روش ساده (فقط با CSS Class)

### مرحله 1: فعال کردن CSS Classes در منو
1. به **Appearance > Menus** بروید
2. روی **Screen Options** (بالای صفحه) کلیک کنید
3. تیک **CSS Classes** را بزنید
4. منو را ذخیره کنید

### مرحله 2: اضافه کردن کلاس به آیتم منو
1. آیتم منویی که می‌خواهید مگامنو شود را باز کنید
2. در قسمت **CSS Classes (optional)** کلاس زیر را اضافه کنید:
   ```
   mega-menu
   ```
3. منو را ذخیره کنید

### مرحله 3: تنظیمات اختیاری (از طریق Custom Fields)

برای تنظیمات بیشتر، می‌توانید از Custom Fields استفاده کنید:

#### تعداد ستون‌ها:
- **Custom Field Name**: `_menu_item_mega_columns`
- **Custom Field Value**: `2` یا `3` یا `4`

#### Full Width:
- **Custom Field Name**: `_menu_item_mega_fullwidth`
- **Custom Field Value**: `1`

#### تصویر:
- **Custom Field Name**: `_menu_item_mega_image`
- **Custom Field Value**: URL تصویر

---

## روش پیشرفته (با کد PHP)

اگر می‌خواهید کنترل بیشتری داشته باشید، می‌توانید از کلاس `Khane_Irani_Mega_Menu` استفاده کنید:

### مثال ساده:

```php
// در functions.php یا یک فایل جدا
add_action('init', function() {
    // ID آیتم منو را پیدا کنید (از Appearance > Menus)
    $menu_item_id = 123; // این را با ID واقعی جایگزین کنید
    
    Khane_Irani_Mega_Menu::apply_to_item($menu_item_id, function() use ($menu_item_id) {
        return khane_irani_mega_menu($menu_item_id)
            ->set_columns(3) // 3 ستون
            ->add_column('محصولات', array(
                array(
                    'title' => 'مبلمان',
                    'url' => home_url('/products/furniture'),
                    'icon' => '🪑',
                ),
                array(
                    'title' => 'دکوراسیون',
                    'url' => home_url('/products/decoration'),
                    'icon' => '🎨',
                ),
            ))
            ->add_column('خدمات', array(
                array(
                    'title' => 'طراحی داخلی',
                    'url' => home_url('/services/interior-design'),
                    'icon' => '🏠',
                ),
            ));
    });
});
```

### پیدا کردن ID آیتم منو:

1. به **Appearance > Menus** بروید
2. روی آیتم منو کلیک راست کنید
3. **Inspect Element** را انتخاب کنید
4. در کد HTML، دنبال `menu-item-123` بگردید (عدد 123 همان ID است)

یا از طریق URL:
- وقتی روی آیتم منو کلیک می‌کنید، در URL صفحه ویرایش، عدد بعد از `post=` همان ID است

---

## انواع مگامنو

### 1. مگامنو 2 ستونه
کلاس: `mega-menu` + Custom Field: `_menu_item_mega_columns = 2`

### 2. مگامنو 3 ستونه (پیش‌فرض)
کلاس: `mega-menu` + Custom Field: `_menu_item_mega_columns = 3`

### 3. مگامنو 4 ستونه
کلاس: `mega-menu` + Custom Field: `_menu_item_mega_columns = 4`

### 4. مگامنو Full Width
کلاس: `mega-menu` + Custom Field: `_menu_item_mega_fullwidth = 1`

### 5. مگامنو با تصویر
کلاس: `mega-menu` + Custom Field: `_menu_item_mega_image = URL تصویر`

---

## نکات مهم

1. **مگامنو فقط در Desktop نمایش داده می‌شود** - در موبایل به صورت منوی عادی نمایش داده می‌شود

2. **حتماً زیرمنو داشته باشید** - آیتم منو باید زیرمنو داشته باشد تا مگامنو کار کند

3. **استایل‌ها خودکار اعمال می‌شوند** - نیازی به CSS اضافی نیست

4. **برای تغییر استایل** می‌توانید فایل `css/navigation-menu.css` را ویرایش کنید

---

## مثال‌های بیشتر

برای مثال‌های بیشتر، فایل `inc/mega-menu-usage.php` را بررسی کنید.

