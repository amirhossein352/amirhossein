# Single Product Page - File Structure Documentation

## 📁 ساختار فایل‌های صفحه تک محصول

این مستندات توضیح می‌دهد که فایل‌های CSS و JavaScript صفحه تک محصول چگونه سازماندهی شده‌اند.

## 🎨 فایل‌های CSS

### 📂 `css/single-product/`

#### `header.css`
**توضیحات:** استایل‌های مربوط به هدر صفحه تک محصول
- هدر اصلی با گرادیانت زیبا
- Breadcrumb navigation
- عنوان و زیرعنوان محصول
- اطلاعات متا محصول (دسته‌بندی، برچسب‌ها، امتیاز)
- دکمه‌های عملیاتی (اشتراک، چاپ، بازگشت)
- المان‌های تزئینی و انیمیشن‌ها
- طراحی responsive برای موبایل

#### `gallery.css`
**توضیحات:** استایل‌های مربوط به گالری و بخش محصول
- گالری ساده‌شده (فقط تصویر شاخص)
- بخش اطلاعات محصول
- دکمه سفارش بهبود یافته
- اطلاعات سریع محصول
- طراحی responsive برای موبایل

#### `features.css`
**توضیحات:** استایل‌های مربوط به بخش ویژگی‌های سرویس
- هدر بخش ویژگی‌ها
- گرید ویژگی‌ها با کارت‌های مدرن
- آیکون‌ها و انیمیشن‌های hover
- بخش CTA بهبود یافته
- طراحی responsive برای موبایل

#### `modal.css`
**توضیحات:** استایل‌های مربوط به پاپ‌آپ تایید خرید
- مودال اصلی با overlay
- محتوای مودال با انیمیشن‌های زیبا
- بخش خلاصه محصول
- دکمه‌های تایید و انصراف
- طراحی responsive برای موبایل

#### `trust.css`
**توضیحات:** استایل‌های مربوط به بخش اعتماد و کیفیت
- هدر بخش اعتماد
- گرید کارت‌های اعتماد
- آیکون‌ها و انیمیشن‌های hover
- طراحی responsive برای موبایل

#### `details.css`
**توضیحات:** استایل‌های مربوط به بخش جزئیات محصول
- FAQ Section با accordion بهبود یافته
- Description Section
- Reviews Section
- Portfolio Section با کارت‌های مدرن
- Counters Section با انیمیشن شمارش
- طراحی responsive برای موبایل

#### `related.css`
**توضیحات:** استایل‌های مربوط به بخش‌های نهایی صفحه تک محصول
- Related Products Section با کارت‌های مدرن
- Final CTA Section برای دعوت به عمل نهایی
- طراحی responsive برای موبایل

### 📄 `single-product-main.css`
**توضیحات:** فایل اصلی CSS که تمام فایل‌های بالا را import می‌کند
- متغیرهای CSS (CSS Variables)
- استایل‌های عمومی و مشترک
- استایل‌های بخش‌های دیگر (Trust, Details, FAQ, Portfolio, Counters)
- طراحی responsive کلی

## ⚡ فایل‌های JavaScript

### 📂 `js/single-product/`

#### `header.js`
**توضیحات:** عملکردهای JavaScript مربوط به هدر
- انیمیشن‌های ورود هدر
- انیمیشن‌های کلیک برای breadcrumb links
- انیمیشن‌های hover برای action buttons
- عملکرد اشتراک‌گذاری محصول
- Toast notifications

#### `modal.js`
**توضیحات:** عملکردهای JavaScript مربوط به پاپ‌آپ تایید خرید
- باز کردن و بستن مودال
- تایید افزودن به سبد خرید
- تایید خرید مستقیم
- مدیریت رویدادهای کیبورد و کلیک
- انیمیشن‌های ورود و خروج

#### `animations.js`
**توضیحات:** عملکردهای JavaScript مربوط به انیمیشن‌ها و تعاملات
- انیمیشن‌های hover برای کارت‌های ویژگی
- Intersection Observer برای انیمیشن ورود
- انیمیشن‌های FAQ accordion
- عملکردهای تعاملی مختلف

#### `details.js`
**توضیحات:** عملکردهای JavaScript مربوط به بخش جزئیات محصول
- FAQ accordion بهبود یافته
- انیمیشن شمارش counters
- انیمیشن‌های hover برای portfolio cards
- عملکردهای تعاملی مختلف

#### `related.js`
**توضیحات:** عملکردهای JavaScript مربوط به بخش‌های نهایی صفحه تک محصول
- انیمیشن‌های hover برای کارت‌های محصولات مرتبط
- عملکردهای تعاملی CTA نهایی
- انیمیشن‌های ورود با AOS

### 📄 `single-product-main.js`
**توضیحات:** فایل اصلی JavaScript که تمام عملکردهای بالا را شامل می‌شود
- تمام عملکردهای هدر
- تمام عملکردهای مودال
- تمام انیمیشن‌ها و تعاملات
- عملکردهای مشترک و عمومی

## 🔧 نحوه استفاده

### روش ۱: استفاده از فایل‌های جداگانه
```html
<!-- در header.php -->
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/single-product/header.css">
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/single-product/gallery.css">
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/single-product/features.css">
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/single-product/modal.css">

<script src="<?php echo get_template_directory_uri(); ?>/js/single-product/header.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/single-product/modal.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/single-product/animations.js"></script>
```

### روش ۲: استفاده از فایل اصلی (پیشنهادی)
```html
<!-- در header.php -->
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/single-product-main.css">
<script src="<?php echo get_template_directory_uri(); ?>/js/single-product-main.js"></script>
```

### 📋 **ساختار نهایی فایل‌ها:**

```
css/single-product/
├── header.css      - هدر و breadcrumb
├── gallery.css     - گالری و بخش محصول
├── features.css    - ویژگی‌های سرویس
├── modal.css       - پاپ‌آپ تایید خرید
├── trust.css       - بخش اعتماد
├── details.css     - جزئیات محصول
└── related.css     - محصولات مرتبط و CTA نهایی

js/single-product/
├── header.js       - عملکردهای هدر
├── modal.js        - عملکردهای پاپ‌آپ
├── animations.js   - انیمیشن‌ها
├── details.js      - عملکردهای جزئیات
└── related.js      - عملکردهای محصولات مرتبط
```

## 📋 مزایای این ساختار

### ✅ **سازماندهی بهتر**
- هر بخش در فایل جداگانه
- کدهای مرتبط کنار هم
- راحت‌تر برای نگهداری

### ✅ **قابلیت توسعه**
- اضافه کردن بخش جدید آسان
- تغییر یک بخش بدون تأثیر بر سایر بخش‌ها
- امکان استفاده مجدد از کدها

### ✅ **عملکرد بهتر**
- امکان بارگذاری انتخابی فایل‌ها
- کاهش حجم فایل‌های اصلی
- بهینه‌سازی بهتر

### ✅ **توسعه تیمی**
- هر توسعه‌دهنده روی بخش خاص کار کند
- کاهش تداخل در کدها
- مدیریت بهتر version control

## 🚀 پیشنهادات برای توسعه آینده

1. **استفاده از CSS Modules یا SCSS**
2. **استفاده از ES6 Modules**
3. **اضافه کردن bundler (Webpack, Vite)**
4. **اضافه کردن TypeScript**
5. **اضافه کردن testing framework**

## 📝 نکات مهم

- تمام فایل‌ها با توضیحات کامل مستند شده‌اند
- کدها به صورت modular نوشته شده‌اند
- طراحی responsive در تمام فایل‌ها رعایت شده
- انیمیشن‌ها و تعاملات بهینه شده‌اند
- سازگاری با مرورگرهای مختلف در نظر گرفته شده

---

**نسخه:** 1.0.0  
**تاریخ:** 2024  
**توسعه‌دهنده:** Zarin Service Team
