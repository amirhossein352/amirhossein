<?php
/**
 * Silence is golden.
 */

